#!/bin/bash

# Set the interface and IP address
INTERFACE="eth1"
IP_ADDRESS="192.168.42.1"
NETMASK="24"

# Configure the interface in /etc/network/interfaces
echo "auto $INTERFACE" | sudo tee -a /etc/network/interfaces > /dev/null
echo "iface $INTERFACE inet static" | sudo tee -a /etc/network/interfaces > /dev/null
echo "address $IP_ADDRESS" | sudo tee -a /etc/network/interfaces > /dev/null
echo "netmask $NETMASK" | sudo tee -a /etc/network/interfaces > /dev/null

# Restart the networking service or bring the interface down and up
if systemctl is-active networking.service > /dev/null 2>&1; then
  sudo systemctl restart networking.service
else
  sudo ifdown $INTERFACE
  sudo ifup $INTERFACE
fi

# Verify the IP address
ip addr show $INTERFACE
echo "Interface $INTERFACE configured with IP address $IP_ADDRESS/$NETMASK"
#echo -e "\n\nLoading simple rc.firewall-iptables version $FWVER..\n"
DEPMOD=/sbin/depmod
MODPROBE=/sbin/modprobe

EXTIF="eth0"
INTIF="eth1"
echo "   External Interface:  $EXTIF"
echo "   Internal Interface:  $INTIF"

#======================================================================
#== No editing beyond this line is required for initial MASQ testing == 
echo -en "   loading modules: "
echo "  - Verifying that all kernel modules are ok"
$DEPMOD -a
echo "----------------------------------------------------------------------"
echo -en "ip_tables, "
$MODPROBE ip_tables
echo -en "nf_conntrack, " 
$MODPROBE nf_conntrack
echo -en "iptable_nat, "
$MODPROBE iptable_nat
echo "----------------------------------------------------------------------"
echo -e "   Done loading modules.\n"
echo "   Enabling forwarding.."
echo "1" > /proc/sys/net/ipv4/ip_forward
echo "   Enabling DynamicAddr.."
echo "1" > /proc/sys/net/ipv4/ip_dynaddr 
echo "   Clearing any existing rules and setting default policy.."

iptables-restore <<-EOF
*nat
-A POSTROUTING -o "$EXTIF" -j MASQUERADE
COMMIT
*filter
:INPUT ACCEPT [0:0]
:FORWARD DROP [0:0]
:OUTPUT ACCEPT [0:0]
-A FORWARD -i "$EXTIF" -o "$INTIF" -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT 
-A FORWARD -i "$INTIF" -o "$EXTIF" -j ACCEPT
-A FORWARD -j LOG
COMMIT
EOF

echo -e "\nrc.firewall-iptables v$FWVER done.\n"
