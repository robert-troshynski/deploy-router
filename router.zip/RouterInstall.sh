#!/bin/bash
#purge old version
echo "apt removal of old entries..."
echo "You can safely ignore messages regarding directory/file not found. And ignore fail to stop a non-existant dhcp."
sudo rm /etc/dhcpcd.conf
sudo rm /etc/dhcp/dhcpd.conf
sudo rm /etc/default/isc-dhcp-server
sudo systemctl stop isc-dhcp-server.service
sudo systemctl disable isc-dhcp-server.service
sleep 10
echo "Installing Router now..."
mkdir /opt/router
sudo chown insight /opt/router
sudo unzip router.zip  -C /opt/router
sudo dpkg -i libip4tc2_1.8.7-1_arm64.deb
sudo dpkg -i libip6tc2_1.8.7-1_arm64.deb
sudo dpkg -i iptables_1.8.7-1_arm64.deb
sudo dpkg -i libirs-export161_9.11.19+dfsg-2.1_arm64.deb
sudo dpkg -i libisccfg-export163_9.11.19+dfsg-2.1_arm64.deb
sudo dpkg -i isc-dhcp-server_4.4.1-2.3+deb11u2_arm64.deb
sudo cp dhcpcd.conf etc/dhcpcd.conf
sudo cp dhcpd.conf /etc/dhcp/dhcpd.conf
sudo cp isc-dhcp-server /etc/default/isc-dhcp-server
sudo systemctl start iptables
sudo systemctl enable iptables
sudo systemctl start isc-dhcp-server.service
sudo systemctl enable isc-dhcp-server.service
sudo chmod 755 nat.sh
sudo cp nat.service /etc/systemd/system/nat.service
sudo systemctl enable nat.service
sudo systemctl start nat.service